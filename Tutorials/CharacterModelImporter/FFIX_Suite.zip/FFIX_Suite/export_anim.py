import bpy
import json
from pathlib import Path
from mathutils import Matrix

class ExportFFIXAnimationOperator(bpy.types.Operator):
    """Export the currently selected animation as a .anim file with bone hierarchy."""
    bl_idname = "object.export_ffiix_animation"
    bl_label = "Export Selected Animation"

    def execute(self, context):
        action = context.object.animation_data.action
        armature = context.object
        scene = context.scene

        if not action:
            self.report({'WARNING'}, "No active action on armature.")
            return {'CANCELLED'}

        frame_start = int(action.frame_range[0])
        frame_end = int(action.frame_range[1])
        apply_negative_root_scale = context.scene.apply_negative_root_scale

        def get_local_matrix(pbone):
            if pbone.parent:
                parent_matrix = pbone.parent.bone.matrix_local.copy()
                parent_matrix.invert()
                local_matrix = parent_matrix @ pbone.bone.matrix_local
            else:
                local_matrix = pbone.bone.matrix_local.copy()
            return local_matrix

        bone_paths = []
        for bone in armature.data.bones:
            path = bone.name
            parent = bone.parent
            while parent:
                path = parent.name + '/' + path
                parent = parent.parent
            bone_paths.append(path)

        transform_list = []
        for path in bone_paths:
            pb = armature.pose.bones.get(path.split('/')[-1])
            if pb is None:
                continue

            rotation_list, position_list, scale_list = [], [], []
            previous_rot, previous_pos, previous_scale = None, None, None

            for frame in range(frame_start, frame_end + 1):
                scene.frame_set(frame)
                context.view_layer.update()

                local_matrix = get_local_matrix(pb)
                current_matrix = pb.matrix_basis.copy()
                final_matrix = local_matrix @ current_matrix

                rot = final_matrix.to_quaternion()
                pos = final_matrix.to_translation()
                scale = final_matrix.to_scale()

                if pb.parent is None and apply_negative_root_scale:
                    scale.x *= -1
                    scale.y *= -1
                    scale.z *= -1

                if (rot != previous_rot) or (pos != previous_pos) or (scale != previous_scale):
                    time_value = (frame - frame_start) / scene.render.fps

                    rotation_list.append({
                        "time": time_value,
                        "x": rot.x, "y": rot.y, "z": rot.z, "w": rot.w,
                        "xInnerTangent": 0, "yInnerTangent": 0, "zInnerTangent": 0, "wInnerTangent": 0,
                        "xOuterTangent": 0, "yOuterTangent": 0, "zOuterTangent": 0, "wOuterTangent": 0
                    })
                    position_list.append({
                        "time": time_value,
                        "x": pos.x, "y": pos.y, "z": pos.z,
                        "xInnerTangent": 0, "yInnerTangent": 0, "zInnerTangent": 0,
                        "xOuterTangent": 0, "yOuterTangent": 0, "zOuterTangent": 0
                    })
                    scale_list.append({
                        "time": time_value,
                        "x": scale.x, "y": scale.y, "z": scale.z,
                        "xInnerTangent": 0, "yInnerTangent": 0, "zInnerTangent": 0,
                        "xOuterTangent": 0, "yOuterTangent": 0, "zOuterTangent": 0
                    })

                    previous_rot = rot.copy()
                    previous_pos = pos.copy()
                    previous_scale = scale.copy()

            transform_list.append({
                "bone": path,
                "localRotation": rotation_list,
                "localPosition": position_list,
                "localScale": scale_list
            })

        result = {
            "name": action.name,
            "frameRate": scene.render.fps,
            "transform": transform_list
        }

        downloads_path = Path.home() / f"Downloads/{action.name}.anim"
        with open(downloads_path, 'w') as f:
            json.dump(result, f, indent=4)

        self.report({'INFO'}, f"Animation exported to {downloads_path}")
        return {'FINISHED'}
