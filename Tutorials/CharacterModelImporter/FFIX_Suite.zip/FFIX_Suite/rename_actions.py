import bpy

class RenameAllActionsOperator(bpy.types.Operator):
    """Renames all existing Action Sets using the custom prefix + number format."""
    bl_idname = "object.rename_all_actions"
    bl_label = "Rename All Actions With Prefix"

    def execute(self, context):
        prefix = context.scene.ffiix_action_prefix.strip()
        if not prefix:
            self.report({'WARNING'}, "Prefix is empty. Set a name in the input box above the button.")
            return {'CANCELLED'}

        actions = bpy.data.actions
        count = 0
        for i, action in enumerate(actions, start=1):
            if not action.fcurves:
                continue
            new_name = f"{prefix}{i:03d}"
            action.name = new_name
            count += 1

        self.report({'INFO'}, f"Renamed {count} actions with prefix '{prefix}'.")
        return {'FINISHED'}

def register_prefix_property():
    bpy.types.Scene.ffiix_action_prefix = bpy.props.StringProperty(
        name="Action Name Prefix",
        description="Prefix used when renaming all animation actions.",
        default="Animation"
    )

def unregister_prefix_property():
    del bpy.types.Scene.ffiix_action_prefix
