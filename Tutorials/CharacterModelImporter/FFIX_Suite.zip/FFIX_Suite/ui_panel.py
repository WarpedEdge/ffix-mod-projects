import bpy

class FFIXAnimationPanel(bpy.types.Panel):
    """This section defines what order it shows up in the UI."""
    bl_label = "Final Fantasy IX Tools"
    bl_idname = "OBJECT_PT_ffiix_animation"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "data"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.rename_ffiix_bones", text="Rename Bones to bone###")
        layout.separator()
        layout.prop(context.scene, "ffiix_action_prefix", text="Prefix")
        layout.operator("object.rename_all_actions", text="Rename All Actions")
        layout.separator()
        layout.operator("object.set_bone_constraints", text="Set Bone Constraints")
        layout.prop(context.scene, "bone_minus_one", text="Bone - 1")
        layout.separator()
        layout.operator("object.export_ffiix_animation", text="Export Selected Animation")
        row = layout.row()
        row.prop(context.scene, "apply_negative_root_scale", text="Apply Negative Root Scale")
