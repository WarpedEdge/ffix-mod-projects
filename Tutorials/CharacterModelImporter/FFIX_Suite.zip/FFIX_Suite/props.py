import bpy

def register_props():
    bpy.types.Scene.apply_negative_root_scale = bpy.props.BoolProperty(
        name="Apply Negative Root Scale",
        description="Apply negative scaling to root bone during export.",
        default=False,
    )
    bpy.types.Scene.bone_minus_one = bpy.props.BoolProperty(
        name="Bone - 1",
        description="When setting bone constraints, and you created a dummy root bone, this will account for that.",
        default=False,
    )

def unregister_props():
    del bpy.types.Scene.apply_negative_root_scale
    del bpy.types.Scene.bone_minus_one
