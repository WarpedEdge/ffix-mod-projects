import bpy

class RenameBonesOperator(bpy.types.Operator):
    """Rename all bones in the active armature to bone000, bone001, etc., and remap F-Curves accordingly."""
    bl_idname = "object.rename_ffiix_bones"
    bl_label = "Rename Bones to bone###"

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != 'ARMATURE':
            self.report({'WARNING'}, "Select an armature object in Object mode")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='EDIT')

        rename_map = {}
        for idx, bone in enumerate(obj.data.edit_bones):
            old_name = bone.name
            new_name = f"bone{idx:03d}"
            if old_name != new_name:
                rename_map[old_name] = new_name
                bone.name = new_name

        bpy.ops.object.mode_set(mode='POSE')

        if rename_map and bpy.data.actions:
            for action in bpy.data.actions:
                for fcurve in action.fcurves:
                    if 'pose.bones["' in fcurve.data_path:
                        for old, new in rename_map.items():
                            search = f'pose.bones["{old}"]'
                            if search in fcurve.data_path:
                                fcurve.data_path = fcurve.data_path.replace(search, f'pose.bones["{new}"]')

        self.report({'INFO'}, f"Renamed {len(rename_map)} bones and remapped animation paths.")
        return {'FINISHED'}
