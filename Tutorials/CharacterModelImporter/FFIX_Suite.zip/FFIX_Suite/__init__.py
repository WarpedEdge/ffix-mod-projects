bl_info = {
    "name": "Final Fantasy IX Tools",
    "author": "WarpedEdge",
    "version": (1, 9),
    "blender": (3, 0, 0),
    "location": "Properties > Final Fantasy IX Tools",
    "description": "Tools for Final Fantasy IX modding: animation export with full bone hierarchy.",
    "category": "Animation",
}

import bpy

from .export_anim import ExportFFIXAnimationOperator
from .rename_actions import RenameAllActionsOperator, register_prefix_property, unregister_prefix_property
from .rename_bones import RenameBonesOperator
from .set_constraints import SetBoneConstraintsOperator
from .ui_panel import FFIXAnimationPanel
from .props import register_props, unregister_props

classes = [
    ExportFFIXAnimationOperator,
    RenameAllActionsOperator,
    RenameBonesOperator,
    SetBoneConstraintsOperator,
    FFIXAnimationPanel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    register_props()
    register_prefix_property()

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    unregister_prefix_property()
    unregister_props()

if __name__ == "__main__":
    register()
