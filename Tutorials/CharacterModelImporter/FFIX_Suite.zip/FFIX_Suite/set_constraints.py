import bpy

class SetBoneConstraintsOperator(bpy.types.Operator):
    """Apply location and rotation constraints to bones from a matching armature in another collection."""
    bl_idname = "object.set_bone_constraints"
    bl_label = "Set Bone Constraints"

    def execute(self, context):
        base_armature = context.object
        if base_armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Please select the Base Armature in Object mode.")
            return {'CANCELLED'}

        animation_armature = None
        for obj in bpy.data.collections.get("Animation Collection", {}).objects:
            if obj.type == 'ARMATURE':
                animation_armature = obj
                break

        if not animation_armature:
            self.report({'ERROR'}, "No armature found in 'Animation Collection'.")
            return {'CANCELLED'}

        base_bones = list(base_armature.pose.bones)
        anim_bones = list(animation_armature.pose.bones)

        offset = 1 if context.scene.bone_minus_one else 0
        constrained_count = 0

        for i, anim_bone in enumerate(anim_bones):
            base_index = i + offset
            if base_index >= len(base_bones):
                break

            base_bone = base_bones[base_index]

            for constraint in list(base_bone.constraints):
                base_bone.constraints.remove(constraint)

            loc_constraint = base_bone.constraints.new(type='COPY_LOCATION')
            loc_constraint.name = "CopyLocationFromAnim"
            loc_constraint.target = animation_armature
            loc_constraint.subtarget = anim_bone.name

            rot_constraint = base_bone.constraints.new(type='COPY_ROTATION')
            rot_constraint.name = "CopyRotationFromAnim"
            rot_constraint.target = animation_armature
            rot_constraint.subtarget = anim_bone.name

            constrained_count += 1

        self.report({'INFO'}, f"Constraints set for {constrained_count} bones.")
        return {'FINISHED'}
